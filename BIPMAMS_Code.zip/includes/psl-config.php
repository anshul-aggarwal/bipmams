<?php

$db_hostname = 'localhost';
$db_database = 'bipmams';
$db_username = '';
$db_password = '';

 
define("CAN_REGISTER", "any");
define("DEFAULT_ROLE", "member");
 
define("SECURE", FALSE);
?>
