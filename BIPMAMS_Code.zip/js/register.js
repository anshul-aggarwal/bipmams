function showhide(t,k)
{
t.style.display="none";
k.style.display="block";
}