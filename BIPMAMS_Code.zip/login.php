<?php // login.php
$db_hostname = 'localhost';
$db_database = 'bipmams';
$db_username = '';
$db_password = '';
?>